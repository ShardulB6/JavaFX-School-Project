//********************************************************************
//  Application.java
//
//  Shardul Bhardwaj T00743760
//  COMP 1231 Assignment 5 Question 1
//  This class launchs and displays a screen and the title of the app to the user
//
//********************************************************************
package com.example.assignment_5_graphical_user_interfaces;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Application extends javafx.application.Application {
    // displays the screen and title
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Application.class.getResource("view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        stage.setTitle("Changing Circle");
        stage.setScene(scene);
        stage.show();
    }

    //launches the program
    public static void main(String[] args) {
        launch();
    }
}