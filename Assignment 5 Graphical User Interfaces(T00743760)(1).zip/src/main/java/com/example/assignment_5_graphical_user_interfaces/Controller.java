//********************************************************************
//  Controller.java
//
//  Shardul Bhardwaj T00743760
//  COMP 1231 Assignment 5 Question 1
//  This class setup what all the interactive things do in the app
//
//********************************************************************
package com.example.assignment_5_graphical_user_interfaces;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.io.File;


public class Controller {

    // sets the fxml items
    public javafx.scene.layout.AnchorPane AnchorPane;
    @FXML
    private Circle circle;
    @FXML
    private RadioButton orangebtn;
    @FXML
    private RadioButton bluebtn;
    @FXML
    private RadioButton yellowbtn;
    @FXML
    private Slider slider;

    MediaPlayer mediaPlayer;



    public void initialize() {
        ToggleGroup colorGroup = new ToggleGroup();

        yellowbtn.setToggleGroup(colorGroup);
        orangebtn.setToggleGroup(colorGroup);
        bluebtn.setToggleGroup(colorGroup);

        orangebtn.setSelected(true);


        // sets the color of the circles via user inputs from the radio buttons
        colorGroup.selectedToggleProperty().addListener(e -> {
            if(orangebtn.isSelected()) {
                circle.setFill(Color.ORANGE);
            } else if(bluebtn.isSelected()) {
                circle.setFill(Color.BLUE);
            } else if(yellowbtn.isSelected()) {
                circle.setFill(Color.YELLOW);
            }
        });
        //sets the slider and changes the radius via the user using the slider
        slider.setValue(circle.getRadius());
        slider.valueProperty().addListener((ov, old_val, new_val) -> {
            circle.setRadius(new_val.doubleValue());
        });

        //plays a beep sound to tell the user that they are not doing what the program told them to do
        Media media = new Media(new File("src\\beep.mp3").toURI().toString());
        mediaPlayer = new MediaPlayer(media);

        AnchorPane.addEventHandler(MouseEvent.MOUSE_PRESSED, mouseEvent -> {
            mediaPlayer.stop();
            mediaPlayer.play();
        });

        circle.addEventHandler(MouseEvent.MOUSE_PRESSED, mouseEvent -> {
            mediaPlayer.stop();
            mediaPlayer.play();
        });

    }

}