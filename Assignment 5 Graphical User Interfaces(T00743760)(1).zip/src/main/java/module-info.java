module com.example.assignment_5_graphical_user_interfaces {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires javafx.media;


    opens com.example.assignment_5_graphical_user_interfaces to javafx.fxml;
    exports com.example.assignment_5_graphical_user_interfaces;
}